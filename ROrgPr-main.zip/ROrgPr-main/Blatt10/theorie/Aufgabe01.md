# Aufgabe 1: Mehrzyklenprozessoren

Mehrzyklenarchiketuren wurden entwickelt, um die Leistung von Einzyklusarchitekturen
zu verbessern. Informieren Sie sich (z.B. in [1, ab Seite 273]) über
Leistungsbegrenzungen von Singlecycle-Architekturen und der Entwicklung von
Multicycle-Implementierungen.

**WICHTIG:** *Mehrzyklenarchiketuren* sind etwas anderes als *Pipelining*.
In dieser Aufgabe geht es **nicht** um Pipelining.
Beide Ansätze dienen der Verbesserung der Timingperformance, unterscheiden sich jedoch in der Umsetzung, in der konkreten Performanceverbesserung und in ihren Vor- und Nachteilen.


Beantworten Sie die folgenden Fragen:

1. (3 Punkte) Timingperformance ist der wichtigste Grund, warum Einzyklus-Prozessoren heut-
zutage höchst selten zu finden sind. Erklären Sie das hauptsächlichen Leistungsproblem einer
Singlecycleimplementierung. Geben Sie ein numerisches Beispiel an, das erlaubt, dieses Pro-
blem abzuschätzen.

Die Leistungsprobleme bei Single-Cycle-Prozessoren sind zum größten Teil, dass der Taktzyklus lang genug sein muss, um den langsamsten Befehl zu verarbeiten. Wenn ein Befehl 
länger dauert als andere, muss der Taktzyklus so bemessen sein, dass er die Dauer des längsten Befehls abdeckt. Und genau das führt zu einer ineffizienten Hardware-Ressourcennutzung und 
erhöht den Zeitaufwand für einfachere Anweisungen. Die Gesamtleistung wird also dadurch sehr ineffizient. [1]

Darüber hinaus trägt der Bedarf des Single-Cycle-MIPS-Prozessors an zwei Addierern, 
zwei ALUs und separaten Befehls- und Datenspeichern erheblich zu höheren Implementierungskosten bei. Im Gegensatz dazu ermöglicht die Strategie des Multizyklusprozessors, Befehle zu 
fragmentieren, eine effizientere Nutzung von Ressourcen. Durch die Verwendung kleinerer Designmodule und die Integration schnellerer oder höher getakteter Takte erreicht die 
Die Multicycle-Implementierung bietet eine verbesserte Leistung und Sparsamkeit. Die Möglichkeit, Funktionseinheiten während der Ausführung eines einzelnen Befehls gemeinsam zu nutzen, 
optimiert nicht nur die Hardwareauslastung, sondern ermöglicht auch ein adaptiveres Design, das unterschiedliche Befehlskomplexitäten in modernen Anwendungen und Arbeitslasten besser 
bewältigen kann. Letztlich entspricht die Umstellung auf Multi-Cycle-Implementierungen dem Bedarf an größerer Flexibilität und Effizienz bei modernen Prozessordesigns. [1] [2]


2. (1 Punkt) Wie verbessert eine Mehrzyklenimplementierung dieses Problemen?
Befehlsfragmentierung: 


Bei einer mehrzyklischen Implementierung wird jeder Befehl in kleinere Schritte unterteilt, die den Funktionsoperationen der Funktionseinheiten entsprechen. 
Dadurch können Befehle eine unterschiedliche Anzahl von Taktzyklen erfordern. 
Reduzierung der Hardwarekomplexität: Im Gegensatz zur Single-Cycle-Implementierung, die für jeden Befehl dedizierte Hardware erfordert, nutzt die Multi-Cycle-Implementierung 
Funktionseinheiten gemeinsam, was zu einer Reduzierung der Gesamtkomplexität der Hardware führt.
Kosteneffizienz: Die gemeinsame Nutzung funktionaler Einheiten ermöglicht eine optimierte Ressourcennutzung und trägt zur Kosteneffizienz bei, da für jede mögliche Anweisung weniger 
spezifische Hardware erforderlich ist. [2]

3. (1 Punkt) Ist Timingperformance die einzige Verbesserung einer Mehrzyklenimplementierung?
Wie verhält es sich mit den benötigten Hardwareressourcen und der Leistungsaufnahme?


Nein, denn wie bereits erwähnt, es Mehrzyklenprozessoren haben nicht nur eine verbesserte sondern auch eine effizientere Nutzung von Hardwareressourcen und eine Anpassung der
Leistungsaufnahme an die tatsächlichen Anforderungen des Prozessors. Durch z.B. die Verwendung kleinerer Designmodule und die Integration schnellerer oder höher getakteter Takte erreicht die 
Multicycle-Implementierung eine verbesserte Leistung und Wirtschaftlichkeit. [2]


[1] Reaz MBI, Jalil J, Rahman LF. Single core hardware modeling of 32-bit MIPS RISC processor with a single clock. Res J Appl Sci Eng Technol. 2012;


[2]	Madhav Singh Solanki, Ms Anuska Sharma, A Review Paper on the Difference between Single-Cycle and
Multi Cycle Processor
