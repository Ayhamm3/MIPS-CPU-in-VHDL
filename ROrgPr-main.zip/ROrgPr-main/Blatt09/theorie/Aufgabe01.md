## Aufgabe 1: Automaten (5 Punkte)
Informieren Sie sich (z.B. in [1, ab Seite 273]) über endliche Zustandsautomaten.
Erarbeiten Sie insbesondere den Unterschied zwischen Moore- und Mealy-Automaten (z.B. [1, ab Seite 279]).
Beantworten Sie anschließend die folgenden Fragen:

1. (1 Punkt) Was ist ein endlicher Zustandsautomat?

Ein endlicher Zustandsautomat ist ein Modell, das verwendet wird, um Systeme zu beschreiben, die eine begrenzte Anzahl von Zuständen haben. Es besteht aus Zuständen, einem Startzustand, Eingaben und Übergangsregeln. Der Automat wechselt je nach Eingabe zwischen diesen Zuständen und kann dabei bestimmte Aktionen ausführen. Endliche Zustandsautomaten werden eingesetzt, um das Verhalten von Systemen zu modellieren.


2. (2 Punkte) Wie unterscheiden sich Moore- und Mealy-Automaten voneinander? Nennen Sie für
beide Varianten jeweils einen Vorteil!

Moore- und Mealy-Automaten sind zwei Typen von endlichen Zustandsautomaten, die sich in der Art und Weise unterscheiden, wie sie Ausgaben erzeugen:

Moore-Automat: Bei einem Moore-Automaten hängt die Ausgabe nur vom aktuellen Zustand des Automaten ab. Jeder Zustand ist mit einer bestimmten Ausgabe assoziiert. Das bedeutet, dass die Ausgabe stabil bleibt, solange sich der Zustand nicht ändert.
Vorteil: Aufgrund der direkten Kopplung der Ausgabe an Zustände ist das Verhalten von Moore-Automaten oft klarer und weniger fehleranfällig, insbesondere in komplexen Systemen.

Mealy-Automat: Im Gegensatz dazu hängt die Ausgabe eines Mealy-Automaten sowohl vom aktuellen Zustand als auch von der aktuellen Eingabe ab. Das bedeutet, dass die Ausgabe sich schneller ändern kann, da sie auf Änderungen in der Eingabe reagiert.
Vorteil: Mealy-Automaten benötigen oft weniger Zustände als Moore-Automaten, um das gleiche Verhalten zu modellieren. Dies kann zu einer effizienteren Nutzung von Ressourcen führen.


3. (2 Punkte) In VHDL lassen sich Automaten über ein bis mehrere Prozesse realisieren. Wonach wird bei einer Mehrprozessimplementierung die Logik aufgeteilt und was sind die Vorteile davon? In bis zu wie viele Prozesse ist eine Aufteilung bei einer Mehrprozessimplementierung sinnvoll?

In VHDL wird bei einer Mehrprozessimplementierung eines Automaten die Logik typischerweise in drei Prozesse aufgeteilt:

Taktsynchroner Prozess für D-Flip-Flops: Verantwortlich für die Zustandsspeicherung des Automaten, reagiert auf Takt- und Reset-Signale.

Kombinatorischer Prozess für die Ausgabelogik: Bestimmt die Ausgabe ausschließlich basierend auf dem aktuellen Zustand (spezifisch für Moore-Automaten).

Kombinatorischer Prozess für die Zustandsübergangslogik: Berechnet den nächsten Zustand basierend auf dem aktuellen Zustand und Eingangssignalen.



David A. Patterson and John L. Hennessy. Rechnerorganisation und -entwurf. Spektrum Akademischer Verlag, September 2005.
Harris, David, und Sarah Harris. "Digital Design and Computer Architecture." Elsevier, 2012
